# Star and Silk Press Kit

Star and Silk is a private daily astrology app for iPhone.

Use these assets for editorial, creator, and launch coverage. Keep claims accurate:

- private daily astrology from a real birth chart
- no account, no ads, no tracking in v1
- free launch version
- Sky Fluency is private self-understanding, not certification or public rank

Do not say Star and Silk predicts the future, provides medical/legal/financial advice, certifies astrologers, or unlocks app features through Shopify.

Public links:

- Site: https://starandsilk.app/
- Press: https://starandsilk.app/press.html
- Support: support@starandsilk.app
