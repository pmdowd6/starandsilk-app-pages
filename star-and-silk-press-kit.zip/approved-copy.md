# Approved Short Copy

One-line:

Private daily astrology from your real birth chart. No account, no ads, no tracking.

Longer:

Star and Silk is a calm iPhone astrology app that turns your birth chart and current sky patterns into one plain-language daily reading.

Sky Fluency:

Become fluent in your own sky. The goal is private pattern recognition and self-trust, not public status.
